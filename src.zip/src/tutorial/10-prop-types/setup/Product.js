import React from 'react';

const Product = () => {
  return <article className='product'>single product</article>;
};

export default Product;
